window.onload = function() {
    document.getElementById("anadir").onclick = function() {
        alert("Poner aqui el código para que el boton te lleva a la página");
    }
}